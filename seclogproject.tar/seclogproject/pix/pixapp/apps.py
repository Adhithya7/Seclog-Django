from django.apps import AppConfig


class PixappConfig(AppConfig):
    name = 'pixapp'
